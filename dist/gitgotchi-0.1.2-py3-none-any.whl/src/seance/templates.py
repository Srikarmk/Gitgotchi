"""Story templates."""

TEMPLATES = {}
