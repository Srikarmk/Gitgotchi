"""Seance module for story generation."""
