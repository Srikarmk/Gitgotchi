"""Pet module."""
