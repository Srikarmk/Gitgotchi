"""Git hooks module."""
